# Create file .cursorrules
# Enable
*Enable all options and the model need to be fast* 

# Cursor settings

![[Pasted image 20240908012326.png]]

# Beta settings
*Enable all*

# Natural Lengua

*your can use natural lenguaje with comments to cursor helps in project*

# Tag
* You can use *@* for a tag files indifidualy or folders to know what does or use in your project o page
* Same think you can use command + enter, to do a search global when to do completion code

# Compose

Command+ shit + I

you ad add files and folder so build a complete funcionality tag all the necesary

# Prompt

Write in markdown, are the instructions for each thing, for example this is a component example for nextjs,

this is a very util for documentation o repetitive tasks

```
new-component.dm

# Instructions for a new component

All of my components should be client components.

  

You'll need to import "use client" at the top of the file.

  

Make sure to define the interface of the component - i like typescript interfaces
```

# Composer projects
In Composer Project you can use a default prompt or your prompt and take one of two files and so that converts in a project who use  for each Composer you do.

